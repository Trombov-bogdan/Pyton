from start_game import StartGame

StartGame()
