import datetime
from calendar import weekday as w

def date_status(a):
    return w(a.year ,a.month, a.day)

_day = 5
_month = 9
_year = 2019
our_data = datetime.date(_year,_month,_day)
weekday = date_status(our_data)
week_list = ['Monday', 'Tusday','Wensday','Thersday', 'Friday', 'Suturday', 'Sunday']
print("Your date is a " ,end = week_list[weekday])