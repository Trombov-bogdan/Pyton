import numpy as np

matrix = np.array([[2,4],[4,7],[8,1]])
print(matrix)
print(matrix.shape)
print(matrix[0])
int_mass = np.arange(100,200,10)
matrix[:,[0,1]] = matrix[:,[1,0]]
print(matrix)
print(matrix[1,0])
