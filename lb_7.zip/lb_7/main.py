from tkinter import Tk
from Exemple import Exemple

def main():

    root_window = Tk()
    app = Exemple()
    root_window.mainloop()

if __name__ == '__main__':
    main()